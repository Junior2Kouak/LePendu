#pragma once
#include <string>
#include <iostream>
#include "Arme.h"

#ifndef EtreVivant_H_INCLUDED
#define EtreVivant_H_INCLUDED

class EtreVivant
{
protected:
	int positionX;
	int positionY;
	std::string nom;
	int PointsDeVie;

public:	EtreVivant();
		EtreVivant(std::string nom, int PointDeVie);

		void SePositionner(int positionX, int positionY);
		virtual void Attaque(EtreVivant cible);
		void RecevoirDegats(EtreVivant source);



};
#endif
