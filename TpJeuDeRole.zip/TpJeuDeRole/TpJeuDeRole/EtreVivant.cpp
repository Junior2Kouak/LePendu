#include "EtreVivant.h"

using namespace std;


EtreVivant::EtreVivant()
{
	this->positionX = 0;
	this->positionY = 0;
	this->nom = "";
	this->PointsDeVie;
}


EtreVivant::EtreVivant(string nom, int PointsDeVie)
{
	this->nom = nom;
	this->PointsDeVie = PointsDeVie;

}
void EtreVivant::SePositionner(int positionX, int positionY)
{
	this->positionX = positionX;
	this->positionY = positionY;

	cout<<this->nom<<" se positionne en x = "<<positionX<<"et y = "<<positionX<<endl;


}

void EtreVivant::Attaque(EtreVivant cible)
{
	cout << this->nom << " attaque " << cible.nom<<endl;
	cible.RecevoirDegats(*this);
}
void EtreVivant::RecevoirDegats(EtreVivant source)
{
	cout << this->nom << " recoit une attaque de " << source.nom<<endl;
	
}