#include <string>
#include <iostream>
#include "EtreVivant.h"
#include"Arme.h"

#ifndef MONSTRE_H_INCLUDED
#define MONSTRE_H_INCLUDED

class Monstre : public EtreVivant
{
protected:
	Arme* arme;

public:
	Monstre();
	Monstre(std::string nom, int PointDeVie, Arme* arme);

	void Attaquer(EtreVivant cible);
};

#endif
