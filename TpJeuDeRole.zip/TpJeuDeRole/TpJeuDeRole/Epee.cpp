#include "Arme.h"
#include "Epee.h"


using namespace std;

Epee::Epee()
	:Arme()
{
	this->longueur = 0;

}


Epee::Epee(string nom, int degats, double longueur)
	:Arme(nom, degats)

{
	this->longueur = longueur;

}

void Epee::Attaque()
{
	cout << "Epee utilise" << endl;
	cout <<"Longueur Epee "<< this->nom << " : " << this->longueur << endl;
	Arme::Attaque();
}
