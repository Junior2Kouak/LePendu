#include <string>
#include <iostream>
#include "Arme.h"
#include "Epee.h"
#include "EtreVivant.h"
#include "Gourdin.h"
#include "Heros.h"
#include "Monstre.h"

using namespace std;

int main()
{
	cout << "----   Test ----" << endl;

	Epee* epee = new Epee("Eperius",100,10);
	Heros* hero = new Heros("Herous",1000,epee);
	
	Gourdin* gourdin = new Gourdin("Gourdius",90,6);
	Monstre* monstre = new Monstre("Monstrus", 500,gourdin);

	hero->SePositionner(10,20);
	monstre->SePositionner(12,22);

	hero->Attaque(*monstre);
	monstre->Attaque(*hero);

	system("pause");
	return 0;
}