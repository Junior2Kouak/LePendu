#include "Arme.h"
#include "Heros.h"
#include "EtreVivant.h"



using namespace std;

Heros::Heros()
	:EtreVivant()
{
	this->arme = NULL;

}


Heros::Heros(std::string nom, int PointDeVie, Arme* arme)


	:EtreVivant(nom, PointDeVie)


{
	this->arme = arme;

}

void Heros::Attaquer(EtreVivant cible)
{
	EtreVivant::Attaque(cible);

}

