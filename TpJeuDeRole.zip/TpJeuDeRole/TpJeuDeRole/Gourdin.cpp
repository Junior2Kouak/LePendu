#include "Arme.h"
#include "Gourdin.h"


using namespace std;

Gourdin::Gourdin()
	:Arme()
{
	this->poids = 0;

}


Gourdin::Gourdin(string nom, int degats, double poids)
	:Arme(nom, degats)

{
	this->poids = poids;

}

void Gourdin::Attaque() {
	cout << "Gourdin utilise" << endl;
	cout << " Poids Gourdin " << this->nom << " : " << this->poids << endl;
	Arme::Attaque();
}