#include "Arme.h"

using namespace std;


Arme::Arme()
{
	this->nom = "";
	this->degats = 0;

}


Arme::Arme(string nom, int degats)
{
	this->nom = nom;
	this->degats = degats;
}

void Arme::Attaque()
{
	cout << this->nom << "a fait" << this->degats << "degats" << endl;
}
