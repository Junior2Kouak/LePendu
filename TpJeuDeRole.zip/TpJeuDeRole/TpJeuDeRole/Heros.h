#include <string>
#include <iostream>
#include "EtreVivant.h"
#include"Arme.h"

#ifndef HEROS_H_INCLUDED
#define HEROS_H_INCLUDED

class Heros : public EtreVivant
{
protected:
	Arme* arme;
public:
	Heros();
	Heros(std::string nom, int PointDeVie, Arme* arme);

	void Attaquer(EtreVivant cible);
};

#endif
