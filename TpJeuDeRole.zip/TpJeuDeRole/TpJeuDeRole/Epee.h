#pragma once
#include <string>
#include <iostream>

#include "Arme.h"

#ifndef EPEE_H_INCLUDED
#define EPEE_H_INCLUDED

class Epee : public Arme
{
protected:
	double longueur;


public:
	Epee();
	Epee(std::string nom, int degats, double longueur);

	virtual void Attaque();


	double Getlongueur() { return this->longueur; };
	void Setlongueur(double longueur) { this->longueur = longueur; };
};

#endif

