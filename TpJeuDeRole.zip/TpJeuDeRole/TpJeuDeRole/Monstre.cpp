#include "Arme.h"
#include "Monstre.h"


using namespace std;

Monstre::Monstre()
	:EtreVivant()
{
	this->arme = NULL;
}

Monstre::Monstre(std::string nom, int PointDeVie, Arme* arme)
	: EtreVivant(nom, PointDeVie)
{
	this->arme = arme;

}

void Monstre::Attaquer(EtreVivant cible)
{
	void Attaquer(EtreVivant cible);
}

